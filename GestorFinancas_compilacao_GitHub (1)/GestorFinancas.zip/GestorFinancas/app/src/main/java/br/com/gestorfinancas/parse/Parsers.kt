package br.com.gestorfinancas.parse

import android.app.Notification
import android.content.Context
import android.net.Uri
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import br.com.gestorfinancas.data.Tx
import br.com.gestorfinancas.data.Vault
import kotlinx.coroutines.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.nio.charset.Charset
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

fun sha(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(32)

object Categorizer {
    private val rules = listOf(
        "Mercado" to listOf("mercado", "supermercado", "atacad", "assai", "carrefour", "extra"),
        "Alimentação" to listOf("ifood", "restaurante", "lanchonete", "padaria", "pizza", "burger", "cafe", "café"),
        "Transporte" to listOf("uber", "99", "posto", "combust", "estaciona", "pedágio", "pedagio"),
        "Saúde" to listOf("farmac", "drogaria", "droga", "clinica", "clínica", "laborat"),
        "Assinaturas" to listOf("netflix", "spotify", "youtube", "prime", "disney", "icloud", "google one"),
        "Contas" to listOf("energia", "enel", "água", "agua", "internet", "claro", "vivo", "tim ", "condom")
    )
    fun guess(desc: String): String {
        val d = desc.lowercase()
        return rules.firstOrNull { (_, ks) -> ks.any { d.contains(it) } }?.first ?: "Sem categoria"
    }
}

/** Lê notificações SOMENTE dos apps da lista abaixo. O texto bruto não é guardado: só valor, data e descrição curta. */
object NotificationParser {
    val packages = mapOf(
        "com.nu.production" to "NUBANK",
        "br.com.bb.android" to "BB"
    )
    private val amountRx = Regex("""R\$\s?(\d{1,3}(?:\.\d{3})*|\d+),(\d{2})""")
    private val incomeWords = listOf("recebeu", "recebido", "recebida", "depósito", "deposito", "estorno", "estornada", "reembolso", "cashback")
    private val expenseWords = listOf("compra", "pagamento", "pagou", "enviou", "enviado", "enviada", "débito", "debito", "saque", "boleto", "transferiu", "transferência realizada")

    fun parse(bank: String, title: String, text: String, postTime: Long): Tx? {
        val full = "$title $text"
        val m = amountRx.find(full) ?: return null
        val cents = (m.groupValues[1].replace(".", "") + m.groupValues[2]).toLong()
        val low = full.lowercase()
        val sign = when {
            incomeWords.any { low.contains(it) } -> 1
            expenseWords.any { low.contains(it) } -> -1
            else -> 0
        }
        val date = Instant.ofEpochMilli(postTime).atZone(ZoneId.systemDefault()).toLocalDate()
        val desc = full.replace(Regex("\\s+"), " ").trim().take(140)
        return Tx(
            bank = bank,
            dateEpochDay = date.toEpochDay(),
            amountCents = if (sign < 0) -cents else cents,
            description = desc,
            category = Categorizer.guess(desc),
            origin = "NOTIFICATION",
            status = if (sign == 0) "PENDING" else "CONFIRMED",
            dedupKey = sha("NOTIF|$bank|$cents|$desc|${postTime / 60000}")
        )
    }
}

class FinanceNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val bank = NotificationParser.packages[sbn.packageName] ?: return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        val tx = NotificationParser.parse(bank, title, text, sbn.postTime) ?: return
        scope.launch { Vault.db(applicationContext).dao().insert(tx) }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}

object Importer {
    data class Result(val added: Int, val reconciled: Int, val skipped: Int)

    suspend fun import(ctx: Context, uri: Uri, bank: String): Result = withContext(Dispatchers.IO) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Arquivo ilegível")
        val text = decode(bytes)
        val rows = if (text.contains("<STMTTRN>", ignoreCase = true)) parseOfx(text, bank) else parseCsv(text, bank)
        val dao = Vault.db(ctx).dao()
        var added = 0; var rec = 0; var skip = 0
        for (t in rows) {
            if (dao.countKey(t.dedupKey) > 0) { skip++; continue }
            val match = dao.findNotificationMatch(t.bank, t.amountCents, t.dateEpochDay)
            if (match != null) { dao.update(t.copy(id = match.id)); rec++ }
            else { dao.insert(t); added++ }
        }
        Result(added, rec, skip)
    }

    private fun decode(b: ByteArray): String {
        val utf8 = String(b, Charsets.UTF_8)
        return if (utf8.contains('\uFFFD')) String(b, Charset.forName("windows-1252")) else utf8
    }

    private fun toCents(raw: String): Long {
        var s = raw.replace("R$", "").trim()
        s = if (s.contains(",")) s.replace(".", "").replace(",", ".") else s
        return BigDecimal(s).movePointRight(2).setScale(0, RoundingMode.HALF_UP).toLong()
    }

    private fun parseOfx(text: String, bank: String): List<Tx> {
        val block = Regex("<STMTTRN>(.*?)(?=</STMTTRN>|<STMTTRN>|</BANKTRANLIST>|$)",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        fun tag(b: String, n: String) = Regex("<$n>([^<\r\n]*)", RegexOption.IGNORE_CASE).find(b)?.groupValues?.get(1)?.trim()
        val seen = HashMap<String, Int>()
        return block.findAll(text).mapNotNull { m ->
            val b = m.groupValues[1]
            val amt = tag(b, "TRNAMT") ?: return@mapNotNull null
            val dt = tag(b, "DTPOSTED")?.take(8) ?: return@mapNotNull null
            val date = runCatching { LocalDate.parse(dt, DateTimeFormatter.BASIC_ISO_DATE) }.getOrNull() ?: return@mapNotNull null
            val desc = tag(b, "MEMO") ?: tag(b, "NAME") ?: ""
            val cents = runCatching { toCents(amt) }.getOrNull() ?: return@mapNotNull null
            val base = "OFX|$bank|" + (tag(b, "FITID") ?: sha("$date|$cents|$desc"))
            val n = seen.merge(base, 1, Int::plus)!!
            Tx(bank = bank, dateEpochDay = date.toEpochDay(), amountCents = cents, description = desc.take(140),
                category = Categorizer.guess(desc), origin = "OFX", status = "CONFIRMED", dedupKey = if (n > 1) "$base#$n" else base)
        }.toList()
    }

    private fun splitCsv(line: String, d: Char): List<String> {
        val out = ArrayList<String>(); val sb = StringBuilder(); var q = false
        for (c in line) when {
            c == '"' -> q = !q
            c == d && !q -> { out.add(sb.toString()); sb.clear() }
            else -> sb.append(c)
        }
        out.add(sb.toString()); return out
    }

    /** Suporta CSV do Nubank (conta: Data,Valor,Identificador,Descrição | cartão: date,category,title,amount) e CSVs genéricos com colunas de data/valor/descrição. */
    private fun parseCsv(text: String, bank: String): List<Tx> {
        val lines = text.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.size < 2) return emptyList()
        val d = if (lines[0].count { it == ';' } > lines[0].count { it == ',' }) ';' else ','
        val header = splitCsv(lines[0], d).map { it.trim().removePrefix("\uFEFF").lowercase() }
        fun idx(vararg n: String) = header.indexOfFirst { it in n }
        val iDate = idx("data", "date"); val iAmt = idx("valor", "amount")
        val iDesc = idx("descrição", "descricao", "title", "description", "histórico", "historico")
        val iId = idx("identificador", "id")
        if (iDate < 0 || iAmt < 0 || iDesc < 0) return emptyList()
        val isCard = header.contains("title")
        val seen = HashMap<String, Int>()
        return lines.drop(1).mapNotNull { line ->
            val c = splitCsv(line, d)
            if (c.size <= maxOf(iDate, iAmt, iDesc)) return@mapNotNull null
            val ds = c[iDate].trim()
            val date = runCatching {
                if (ds.contains("/")) LocalDate.parse(ds, DateTimeFormatter.ofPattern("dd/MM/yyyy")) else LocalDate.parse(ds.take(10))
            }.getOrNull() ?: return@mapNotNull null
            var cents = runCatching { toCents(c[iAmt]) }.getOrNull() ?: return@mapNotNull null
            if (isCard) cents = -cents
            val desc = c[iDesc].trim()
            val base = "CSV|$bank|" + (if (iId >= 0 && c.getOrNull(iId).orEmpty().isNotBlank()) c[iId].trim() else sha("$date|$cents|$desc"))
            val n = seen.merge(base, 1, Int::plus)!!
            Tx(bank = bank, dateEpochDay = date.toEpochDay(), amountCents = cents, description = desc.take(140),
                category = Categorizer.guess(desc), origin = "CSV", status = "CONFIRMED", dedupKey = if (n > 1) "$base#$n" else base)
        }
    }
}
