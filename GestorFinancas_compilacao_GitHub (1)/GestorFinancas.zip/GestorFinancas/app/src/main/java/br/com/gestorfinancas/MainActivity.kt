package br.com.gestorfinancas

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import br.com.gestorfinancas.ui.AppTheme
import br.com.gestorfinancas.ui.LockScreen
import br.com.gestorfinancas.ui.MainScreen

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)
    private var lockMsg by mutableStateOf("")
    private var prompting = false

    companion object {
        /** Evita re-bloquear ao abrir seletor de arquivos / configurações do sistema. */
        @Volatile var suppressNextLock = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Bloqueia print/gravação de tela e esconde o conteúdo na tela de apps recentes.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            AppTheme {
                if (unlocked) MainScreen() else LockScreen(lockMsg) { authenticate() }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (!unlocked) authenticate()
    }

    override fun onStop() {
        super.onStop()
        if (suppressNextLock) suppressNextLock = false else unlocked = false
    }

    private fun authenticate() {
        if (prompting) return
        val auth = BIOMETRIC_STRONG or DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            lockMsg = "Configure um bloqueio de tela (PIN, padrão ou biometria) para usar o app."
            return
        }
        lockMsg = ""
        prompting = true
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    prompting = false; unlocked = true
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { prompting = false }
            })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Gestor de Finanças")
                .setSubtitle("Confirme sua identidade")
                .setAllowedAuthenticators(auth)
                .build()
        )
    }
}
