package br.com.gestorfinancas.ui

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import br.com.gestorfinancas.MainActivity
import br.com.gestorfinancas.data.Tx
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

private val brl: NumberFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
fun money(cents: Long): String = brl.format(cents / 100.0)
private val bankNames = mapOf("NUBANK" to "Nubank", "BB" to "Banco do Brasil", "OUTRO" to "Outro")

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun LockScreen(message: String, onUnlock: () -> Unit) {
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Icon(Icons.Default.Lock, null, Modifier.size(56.dp))
            Spacer(Modifier.height(16.dp))
            Text("Gestor de Finanças", style = MaterialTheme.typography.headlineSmall)
            if (message.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(message) }
            Spacer(Modifier.height(24.dp))
            Button(onClick = onUnlock) { Text("Desbloquear") }
        }
    }
}

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val pending by vm.pending.collectAsState()
    val msg by vm.message.collectAsState()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.message.value = null } }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("Resumo") })
                NavigationBarItem(tab == 1, { tab = 1 }, {
                    BadgedBox(badge = { if (pending.isNotEmpty()) Badge { Text("${pending.size}") } }) {
                        Icon(Icons.AutoMirrored.Filled.List, null)
                    }
                }, label = { Text("Lançamentos") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Add, null) }, label = { Text("Importar") })
                NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Default.Settings, null) }, label = { Text("Ajustes") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> SummaryScreen(vm)
                1 -> TransactionsScreen(vm)
                2 -> ImportScreen(vm)
                else -> SettingsScreen(vm)
            }
        }
    }
}

@Composable
private fun MonthBar(vm: MainViewModel) {
    val m by vm.month.collectAsState()
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        IconButton({ vm.shift(-1) }) { Icon(Icons.Default.KeyboardArrowLeft, "Mês anterior") }
        Text(m.format(DateTimeFormatter.ofPattern("MMMM 'de' yyyy", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() },
            style = MaterialTheme.typography.titleMedium)
        IconButton({ vm.shift(1) }) { Icon(Icons.Default.KeyboardArrowRight, "Próximo mês") }
    }
}

@Composable
fun SummaryScreen(vm: MainViewModel) {
    val list by vm.monthTx.collectAsState()
    val income = list.filter { it.amountCents > 0 }.sumOf { it.amountCents }
    val expense = list.filter { it.amountCents < 0 }.sumOf { it.amountCents }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        MonthBar(vm)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Saldo do mês", style = MaterialTheme.typography.labelLarge)
                Text(money(income + expense), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("Receitas"); Text(money(income))
                }
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("Despesas"); Text(money(expense))
                }
            }
        }
        Text("Por banco", style = MaterialTheme.typography.titleSmall)
        list.groupBy { it.bank }.forEach { (b, l) ->
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(bankNames[b] ?: b); Text(money(l.sumOf { it.amountCents }))
            }
        }
        Text("Despesas por categoria", style = MaterialTheme.typography.titleSmall)
        list.filter { it.amountCents < 0 }.groupBy { it.category }
            .mapValues { (_, l) -> l.sumOf { it.amountCents } }.entries.sortedBy { it.value }
            .forEach { (c, v) -> Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(c); Text(money(v)) } }
        if (list.isEmpty()) Text("Sem lançamentos neste mês. Ative as notificações em Ajustes ou importe um extrato.")
    }
}

@Composable
fun TransactionsScreen(vm: MainViewModel) {
    val list by vm.monthTx.collectAsState()
    val pending by vm.pending.collectAsState()
    var editing by remember { mutableStateOf<Tx?>(null) }
    var creating by remember { mutableStateOf(false) }

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Spacer(Modifier.height(8.dp)); MonthBar(vm) }
        item { Button({ creating = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Novo lançamento") } }
        if (pending.isNotEmpty()) {
            item { Text("Pendentes de classificação (${pending.size})", style = MaterialTheme.typography.titleSmall) }
            items(pending, key = { "p${it.id}" }) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${bankNames[t.bank]} · ${money(abs(t.amountCents))}", fontWeight = FontWeight.Bold)
                        Text(t.description, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton({ vm.classify(t, false) }) { Text("Despesa") }
                            TextButton({ vm.classify(t, true) }) { Text("Receita") }
                            TextButton({ vm.delete(t) }) { Text("Excluir") }
                        }
                    }
                }
            }
            item { HorizontalDivider() }
        }
        items(list, key = { it.id }) { t ->
            Row(Modifier.fillMaxWidth().clickable { editing = t }.padding(vertical = 6.dp), Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(t.description.ifBlank { t.category }, maxLines = 2)
                    Text("${LocalDate.ofEpochDay(t.dateEpochDay).format(DateTimeFormatter.ofPattern("dd/MM"))} · ${bankNames[t.bank]} · ${t.category}",
                        style = MaterialTheme.typography.bodySmall)
                }
                Text(money(t.amountCents), color = if (t.amountCents < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    if (creating) TxDialog(null, { creating = false }, { vm.save(it); creating = false }, null)
    editing?.let { t ->
        TxDialog(t, { editing = null }, { vm.save(it); editing = null }, { vm.delete(t); editing = null })
    }
}

@Composable
private fun TxDialog(initial: Tx?, onDismiss: () -> Unit, onSave: (Tx) -> Unit, onDelete: (() -> Unit)?) {
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var value by remember { mutableStateOf(initial?.let { "%d,%02d".format(abs(it.amountCents) / 100, abs(it.amountCents) % 100) } ?: "") }
    var expense by remember { mutableStateOf((initial?.amountCents ?: -1L) < 0) }
    var category by remember { mutableStateOf(initial?.category ?: "Sem categoria") }
    var bank by remember { mutableStateOf(initial?.bank ?: "NUBANK") }
    val cents = value.replace(".", "").replace(",", ".").toBigDecimalOrNull()?.movePointRight(2)?.toLong()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Novo lançamento" else "Editar lançamento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(desc, { desc = it }, label = { Text("Descrição") })
                OutlinedTextField(value, { value = it }, label = { Text("Valor (R$)") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Categoria") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(expense, { expense = true }, { Text("Despesa") })
                    FilterChip(!expense, { expense = false }, { Text("Receita") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bankNames.forEach { (k, n) -> FilterChip(bank == k, { bank = k }, { Text(n) }) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = cents != null && cents > 0, onClick = {
                val signed = if (expense) -cents!! else cents!!
                onSave(
                    initial?.copy(description = desc, amountCents = signed, category = category, bank = bank)
                        ?: Tx(bank = bank, dateEpochDay = LocalDate.now().toEpochDay(), amountCents = signed, description = desc,
                            category = category, origin = "MANUAL", status = "CONFIRMED", dedupKey = "MANUAL|${UUID.randomUUID()}")
                )
            }) { Text("Salvar") }
        },
        dismissButton = {
            Row {
                onDelete?.let { TextButton(it) { Text("Excluir") } }
                TextButton(onDismiss) { Text("Cancelar") }
            }
        }
    )
}

@Composable
fun ImportScreen(vm: MainViewModel) {
    var bank by remember { mutableStateOf("NUBANK") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.import(uri, bank)
    }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Importar extrato", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(bank == "NUBANK", { bank = "NUBANK" }, { Text("Nubank") })
            FilterChip(bank == "BB", { bank = "BB" }, { Text("Banco do Brasil") })
        }
        Button({ MainActivity.suppressNextLock = true; picker.launch(arrayOf("*/*")) }) { Text("Escolher arquivo (.ofx ou .csv)") }
        Text("Prefira OFX: traz um identificador único por transação, então reimportar o mesmo período não duplica. " +
            "Lançamentos que já chegaram por notificação são conciliados (não duplicam).")
        Text("Nubank: no app, em Conta ou Cartão, exporte o extrato/fatura em OFX ou CSV.\n" +
            "Banco do Brasil: no Internet Banking, em Extrato, escolha exportar em OFX (Money/Quicken).",
            style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) enabled = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Leitura de notificações", style = MaterialTheme.typography.titleMedium)
        Text(if (enabled) "Ativa — lendo apenas Nubank e Banco do Brasil." else "Desativada.")
        Button({
            MainActivity.suppressNextLock = true
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Abrir acesso a notificações") }
        Text("Se o Android bloquear a opção (app instalado fora da Play Store), abra Info do app > menu ⋮ > Permitir configurações restritas.",
            style = MaterialTheme.typography.bodySmall)
        HorizontalDivider()
        Text("Segurança", style = MaterialTheme.typography.titleMedium)
        Text("• Banco de dados criptografado (SQLCipher AES-256), chave protegida pelo Android Keystore\n" +
            "• Bloqueio por biometria/PIN ao abrir e ao voltar para o app\n" +
            "• Prints e prévia em apps recentes bloqueados\n" +
            "• Sem permissão de internet: nenhum dado sai do aparelho\n" +
            "• Backup do Android desativado\n" +
            "• Texto bruto das notificações não é armazenado")
        HorizontalDivider()
        OutlinedButton({ confirmWipe = true }) { Text("Apagar todos os dados") }
    }
    if (confirmWipe) AlertDialog(
        onDismissRequest = { confirmWipe = false },
        title = { Text("Apagar tudo?") },
        text = { Text("Todos os lançamentos serão removidos permanentemente.") },
        confirmButton = { TextButton({ vm.wipe(); confirmWipe = false }) { Text("Apagar") } },
        dismissButton = { TextButton({ confirmWipe = false }) { Text("Cancelar") } }
    )
}
