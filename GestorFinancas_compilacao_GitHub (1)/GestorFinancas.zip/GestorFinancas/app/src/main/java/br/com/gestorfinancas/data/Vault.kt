package br.com.gestorfinancas.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.room.Room
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Banco SQLCipher (AES-256). A senha do banco é aleatória (32 bytes) e fica guardada
 * apenas cifrada por uma chave do Android Keystore (hardware/TEE), que nunca sai do aparelho.
 */
object Vault {
    private const val ALIAS = "gf_master_key"
    @Volatile private var instance: AppDb? = null

    fun db(ctx: Context): AppDb = instance ?: synchronized(this) {
        instance ?: build(ctx.applicationContext).also { instance = it }
    }

    private fun build(ctx: Context): AppDb {
        System.loadLibrary("sqlcipher")
        val factory = SupportOpenHelperFactory(passphrase(ctx))
        return Room.databaseBuilder(ctx, AppDb::class.java, "gestor.db")
            .openHelperFactory(factory)
            .build()
    }

    private fun masterKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun passphrase(ctx: Context): ByteArray {
        val prefs = ctx.getSharedPreferences("vault", Context.MODE_PRIVATE)
        val key = masterKey()
        prefs.getString("p", null)?.let { stored ->
            val raw = Base64.decode(stored, Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            return cipher.doFinal(raw, 12, raw.size - 12)
        }
        val pass = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val blob = cipher.iv + cipher.doFinal(pass)
        prefs.edit().putString("p", Base64.encodeToString(blob, Base64.NO_WRAP)).commit()
        return pass
    }
}
