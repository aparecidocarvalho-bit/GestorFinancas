package br.com.gestorfinancas.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.gestorfinancas.data.Tx
import br.com.gestorfinancas.data.Vault
import br.com.gestorfinancas.parse.Importer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.YearMonth
import kotlin.math.abs

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = Vault.db(app).dao()

    val month = MutableStateFlow(YearMonth.now())
    val message = MutableStateFlow<String?>(null)

    val monthTx: StateFlow<List<Tx>> = month
        .flatMapLatest { dao.observeConfirmed(it.atDay(1).toEpochDay(), it.atEndOfMonth().toEpochDay()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pending: StateFlow<List<Tx>> = dao.observePending()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun shift(d: Int) { month.value = month.value.plusMonths(d.toLong()) }

    fun classify(tx: Tx, income: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        val v = abs(tx.amountCents)
        dao.update(tx.copy(amountCents = if (income) v else -v, status = "CONFIRMED"))
    }

    fun save(tx: Tx) = viewModelScope.launch(Dispatchers.IO) {
        if (tx.id == 0L) dao.insert(tx) else dao.update(tx)
    }

    fun delete(tx: Tx) = viewModelScope.launch(Dispatchers.IO) { dao.delete(tx) }

    fun wipe() = viewModelScope.launch(Dispatchers.IO) { dao.clearAll(); message.value = "Todos os dados foram apagados." }

    fun import(uri: Uri, bank: String) = viewModelScope.launch {
        message.value = try {
            val r = Importer.import(getApplication(), uri, bank)
            "${r.added} novos, ${r.reconciled} conciliados com notificações, ${r.skipped} já existentes."
        } catch (e: Exception) {
            "Não consegui ler o arquivo (use .ofx ou .csv)."
        }
    }
}
