package br.com.gestorfinancas.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** amountCents: positivo = receita, negativo = despesa. Pendentes guardam valor absoluto até o usuário classificar. */
@Entity(tableName = "transactions", indices = [Index(value = ["dedupKey"], unique = true)])
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bank: String,            // NUBANK | BB | OUTRO
    val dateEpochDay: Long,
    val amountCents: Long,
    val description: String,
    val category: String = "Sem categoria",
    val origin: String,          // NOTIFICATION | OFX | CSV | MANUAL
    val status: String,          // CONFIRMED | PENDING
    val dedupKey: String
)

@Dao
interface TxDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(tx: Tx): Long

    @Update suspend fun update(tx: Tx)
    @Delete suspend fun delete(tx: Tx)

    @Query("DELETE FROM transactions")
    suspend fun clearAll()

    @Query("SELECT * FROM transactions WHERE status = 'CONFIRMED' AND dateEpochDay BETWEEN :from AND :to ORDER BY dateEpochDay DESC, id DESC")
    fun observeConfirmed(from: Long, to: Long): Flow<List<Tx>>

    @Query("SELECT * FROM transactions WHERE status = 'PENDING' ORDER BY dateEpochDay DESC, id DESC")
    fun observePending(): Flow<List<Tx>>

    @Query("SELECT COUNT(*) FROM transactions WHERE dedupKey = :key")
    suspend fun countKey(key: String): Int

    @Query("SELECT * FROM transactions WHERE origin = 'NOTIFICATION' AND status = 'CONFIRMED' AND bank = :bank AND amountCents = :amount AND dateEpochDay = :day LIMIT 1")
    suspend fun findNotificationMatch(bank: String, amount: Long, day: Long): Tx?
}

@Database(entities = [Tx::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TxDao
}
