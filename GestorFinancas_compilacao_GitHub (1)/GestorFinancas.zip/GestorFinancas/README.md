# Gestor de Finanças (Android, Kotlin + Compose)

Uso pessoal. Fontes de dados: notificações do Nubank e do Banco do Brasil + importação de extrato OFX/CSV.

## Compilar
1. Abra a pasta no Android Studio (Ladybug ou mais novo). Ele baixa o Gradle e sincroniza sozinho.
2. Conecte o celular (depuração USB) e rode, ou use Build > Build APK(s).
3. No app: Ajustes > "Abrir acesso a notificações" e ative o Gestor de Finanças.

## Segurança (já implementada)
- SQLCipher AES-256; senha aleatória do banco cifrada por chave do Android Keystore
- Biometria/PIN (BiometricPrompt) e re-bloqueio ao sair do app
- FLAG_SECURE, allowBackup=false, sem permissão INTERNET, sem analytics
- Só lê notificações dos pacotes em NotificationParser.packages; texto bruto não é salvo
- Para release: use assinatura própria e mantenha isMinifyEnabled=true

## Ajustes comuns
- Formatos de notificação mudam: ajuste as listas de palavras/regex em `parse/Parsers.kt` (NotificationParser).
  Notificações sem direção clara (receita/despesa) caem em "Pendentes" para você classificar.
- Categorias automáticas: `Categorizer` em `parse/Parsers.kt`.

## Open Finance (opcional, ainda não incluído)
Exige internet e um agregador regulado (Pluggy, Belvo). A chave secreta do agregador NÃO deve ficar no APK;
use um pequeno backend seu para gerar o connect token. Quando for adicionar, crie um build flavor separado
com a permissão INTERNET, mantendo a versão "local" sem rede.
